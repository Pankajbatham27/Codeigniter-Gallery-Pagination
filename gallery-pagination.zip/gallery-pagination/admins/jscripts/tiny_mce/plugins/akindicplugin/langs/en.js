tinyMCE.addToLang('indic',{
	toggle_indic_transliteration : 'Toggle Indic transliteration',
	choose_script: 'Choose script:',
	script_english: 'English (Roman)',
	script_devanagari: 'Devanagari',
	script_bengoli: 'Bengoli',
	script_gujarati: 'Gujarati',
	script_kannada: 'Kannada',
	script_malayalam: 'Malayalam',
	script_gurumukhi: 'Gurumukhi',
	script_telugu: 'Telugu',
	script_urdu: 'Urdu'
});
